# Descripción del Reto
# Tu tarea es implementar una función que reciba una cadena de datos en el formato clave:valor|clave:valor|... y devuelva un resultado indicando si los datos son válidos y la versión de la validación aplicada.
#
# La cadena value contendrá diferentes pares clave:valor separados por |.
#
# Deberás validar cada par basado en los siguientes criterios:
#
# name: Debe estar presente y tener al menos 5 caracteres.
# age: Debe ser un número mayor o igual a 18.
# state: Debe estar presente y tener al menos 5 caracteres.
# zipcode: Debe ser un código postal válido de 5 dígitos.
# status: Solo acepta los valores soltero o casado (sin importar mayúsculas o minúsculas).
#
# La función debe devolver un string con el formato Version {version}|{resultado}, donde:
#
# version será 4.0 si se encuentra zipcode o status, o 3.3 si estos no están presentes.
# resultado será Success si todos los valores son válidos, de lo contrario, Error.



#LIA REBECA RAMIREZ VELAZQUEZ 
# VACANTE: ING. SERV WEB
# RETO 1
# 

import re

def validar_datos(value):
    
    zipcode = re.search(r"zipcode:\d{5}(\||$)", value)
    status = re.search(r"status:(soltero|casado)(\||$)", value, re.IGNORECASE)
    name  =  re.search(r"name:[a-zA-Z]{5,}(\||$)", value)
    state = re.search(r"state:[a-zA-Z]{5,}(\||$)", value)
    edad = re.search(r"age:(1[89]|[2-9][0-9])(\||$)", value)

    version = "3.3"
        
    if not name:
        return "Version"+version+"|Error"
    
    if not edad :
        return "Version"+version+"|Error"

    if not state:
        return "Version"+version+"|Error"

  
    if "zipcode:" in value:
        version = "4.0"
        if not zipcode:
            return "Version" + version + "|Error"

    if "status:" in value:
        version = "4.0"
        if not status:
            return "Version" + version + "|Error"

    return "Version"+version+"|Succes"
    

# Casos correctos
print(validar_datos("name:Andrea|age:29|state:Jalisco|zipcode:44100|status:Soltero"))
print(validar_datos("name:PedroL|age:22|state:Nayarit"))

# Casos incorrectos
print(validar_datos("name:Ana|age:19|state:Yucatán|zipcode:1234|status:Casado"))
print(validar_datos("name:Roberto|age:17|state:Sonora"))
print(validar_datos("name:Elisa|age:30|state:DF|zipcode:99999|status:divorciado"))


    
