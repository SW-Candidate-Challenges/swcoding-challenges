// Este archivo contiene las pruebas de validacion del archivo Solucion_reto_2.js

//El arrego de pruebasValidas y pruebasInvalidas contienen los paramentros a probar
const pruebasValidas = [
    [5,3],
    [-10,4],
    [0,0],
    [123,877]
]

const pruebasInvalidas = [
    [5.5,2],
    ["10",5],
    [8,null],
    [true,3],
    [[], {}]
]

//Testeo de la funcion para validar que si retorne correctamente los fallos y los aciertos
console.log("\nPruebas validas");

for (let index = 0; index < pruebasValidas.length; index++) {    
    const [a, b] = pruebasValidas[index]
    console.log(sumarNumeros(a, b));
}

console.log("\nPruebas invalidas");

for (let index = 0; index < pruebasInvalidas.length; index++) {    
    const [a, b] = pruebasInvalidas[index]
    console.log(sumarNumeros(a, b));
}