// Este archivo contiene la solucion al reto 2

// la funcion sumarNumeros revice 2 numeros enteros y retorna la suma de ambos
const sumarNumeros = (a,b) => {
    if (!Number.isInteger(a) || !Number.isInteger(b)) return "Ambos parámetros deben ser números enteros."
    return `El resultado de la suma es: ${a + b} SW`
}