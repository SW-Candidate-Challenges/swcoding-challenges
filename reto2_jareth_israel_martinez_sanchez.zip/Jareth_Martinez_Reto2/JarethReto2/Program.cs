﻿// Jareth Israel Martínez Sánchez

class Reto2 {
    static void Main(){ // Función main (Función principal)
        Console.WriteLine("Introduce el primer número:");
        var primerNumero = Console.ReadLine(); // Lectura de consola del primer número

        Console.WriteLine("Intoduce el segundo número:");
        var segundoNumero = Console.ReadLine();// Lectura de consola del segundo número

        Console.WriteLine(sumarNumerosEnteros(primerNumero, segundoNumero)); // Al llamarse la función dentro de WriteLine, se muestra en consola el texto que retorna la función
    }

    static string sumarNumerosEnteros(object a, object b) { // Función que suma números enteros, devuelve un string
        
        string resultadoStr; // String para guardar la cadena resultado

        bool aEsEntero = int.TryParse(a?.ToString(), out int numeroA); // Bandera para verificar que el objeto "a" no es nulo y lo intenta transformar en entero, finalmente guarda la salida en un entero "numeroA"
        bool bEsEntero = int.TryParse(b?.ToString(), out int numeroB); // Bandera para verificar que el objeto "b" no es nulo y lo intenta transformar en entero, finalmente guarda la salida en un entero "numeroB"
        
        if(aEsEntero && bEsEntero){ // Si ambas banderas indican que los números son enteros, entra en el "if"
            int resultadoSuma = numeroA + numeroB; // Suma "numeroA" y "numeroB" en una variable "resultadoSuma"
            resultadoStr = $"El resultado de la suma es: {resultadoSuma} SW"; // Guarda en la cadena de resultado el texto y el resultado si se logró sumar
        } else {
            resultadoStr = "Ambos parámetros deben ser números enteros"; // Si alguno de los números no era entero, devuelve un mensaje de error"
        }

        return resultadoStr; // Devuelve la cadena de resultado
    }
}