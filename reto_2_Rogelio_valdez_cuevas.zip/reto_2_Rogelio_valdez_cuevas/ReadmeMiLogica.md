# ReadmeMiLogica.md

## Descripción General
Este proyecto es un programa en Python que solicita al usuario dos números enteros, valida que ambas entradas sean correctas y muestra el resultado de su suma. Además, incluye algunas pruebas para asegurar que la lógica de suma aunque no cubre los casos de validación conr esultado en pantalla, solo si es correcto o no.

## Estructura del Código

### 1. sumOfTwoNumbers(firstNumber, secondNumber)
- **Propósito:** Suma dos números y devuelve el resultado.
- **Uso:**
    ```python
    resultado = sumOfTwoNumbers(5, 3)  # resultado = 8
    ```

### 2. isInt(prompt, position)
- **Propósito:** Solicita al usuario un valor y valida que sea un número entero.
- **Validaciones:**
  - Si el usuario ingresa un valor booleano (`true` o `false`), muestra un mensaje de error.
  - Si el usuario ingresa un número decimal, muestra un mensaje de error.
  - Si el usuario ingresa una cadena que no es un número, muestra un mensaje de error.
  - Solo acepta números enteros.
- **Uso:**
    ```python
    numero = isInt("Ingresa un número: ", "a")
    ```

### 3. main()
- **Propósito:** Función principal que otorga la interacción con el usuario.
- **Flujo:**
  1. Solicita el primer número usando `isInt`.
  2. Solicita el segundo número usando `isInt`.
  3. Muestra el resultado de la suma usando `sumOfTwoNumbers`.

### 4. Pruebas 
Para la realiuzacion de las pruebas se utilizo unittest: puede encontrar la documentacion aqui : https://docs.python.org/3/library/unittest.html
- **Ubicación:** Al final del archivo `reto_2_solved.py`.
- **Propósito:** Verificar que la función de suma funciona correctamente con distintos tipos de entrada.
- **Casos cubiertos:**
  - Sumas válidas (enteros positivos, negativos, cero).
  - Casos inválidos (booleanos, strings, decimales, None, listas, diccionarios), marcados como "expected failure" porque la función original no lanza error.
- **Ejecución:**
  - Ejecutando `python3 reto_2_solved.py` se corre el programa y los tests.
  - También puedes correr `python3 reto_2_solved.py -v` para obtener un reporte detallado de los tests.

## Ejemplo de Uso en bash
```
$ python3 reto_2_solved.py
Suma de dos números
ingresa el primer numero: 5
ingresa el segundo numero: 4
a = 5 , b = 4    El resultado de la suma es:  9 SW
```

## Manejo de Errores y Validaciones
- El programa asegura que solo se ingresen números enteros válidos.
- Si el usuario ingresa un valor inválido, se muestra un mensaje específico según el tipo de error y se vuelve a solicitar la entrada.
- La suma solo se realiza si ambas entradas son válidas.
---

**Autor:** Rogelio Valdez Cuevas
**Fecha:** Junio 2025
