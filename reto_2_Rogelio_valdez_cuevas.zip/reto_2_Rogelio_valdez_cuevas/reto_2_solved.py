
def sumOfTwoNumbers(firstNumber, secondNumber):
    #Suma dos números y devuelve el resultado
    return firstNumber + secondNumber

def isInt(prompt, position):
    # Valida que la entrada del usuario sea un número entero
    while True:
        valor = input(prompt).strip()
        # Verificar si es booleano
        if valor.lower() in ('true', 'false'):
            print("Ambos parámetros deben ser números enteros.  ", position, "es booleano")
        # Verificar si es decimal
        elif '.' in valor:
            print("Ambos parámetros deben ser números enteros.  ", position, "es un numero decimal")
        # Verificar si es un string no numérico
        elif not valor.lstrip('-').isdigit():
            print("Ambos parámetros deben ser números enteros.  ", position, "es string")
        else:
            # Si pasa todas las validaciones, convertir a entero y retornar
            return int(valor)

def main():
    #Función principal que maneja la lógica del programa
    print("Suma de dos números")
    firstNumber = isInt("ingresa el primer numero: ", "a")
    secondNumber = isInt("ingresa el segundo numero: ", "b")
    print("a =", firstNumber,", b =", secondNumber,"   El resultado de la suma es: ", sumOfTwoNumbers(firstNumber, secondNumber), "SW")

import unittest
class TestSumOfTwoNumbers(unittest.TestCase):
    #Test de casos validos
    def test_positive(self):
        self.assertEqual(sumOfTwoNumbers(5, 3), 8)

    def test_negative(self):
        self.assertEqual(sumOfTwoNumbers(-10, 4), -6)
    
    def test_zero(self):
        self.assertEqual(sumOfTwoNumbers(0, 0), 0)

    def test_positive(self):
        self.assertEqual(sumOfTwoNumbers(123, 877), 1000)
    
    #Test de casos invalidos
    @unittest.expectedFailure
    def test_boolean(self):
        self.assertEqual(sumOfTwoNumbers(5.5, 2))

    @unittest.expectedFailure
    def test_string(self):
        self.assertEqual(sumOfTwoNumbers("10", "5"))
    
    @unittest.expectedFailure
    def test_none(self):
        self.assertEqual(sumOfTwoNumbers(8, None))
    
    @unittest.expectedFailure
    def test_decimal(self):
        self.assertEqual(sumOfTwoNumbers(True, 3))
    
    @unittest.expectedFailure
    def test_float(self):
        self.assertEqual(sumOfTwoNumbers([], {}))
    
    
    
if __name__ == "__main__":
    main()
    unittest.main()