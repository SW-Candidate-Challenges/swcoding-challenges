﻿// Jareth Israel Martínez Sánchez
class Reto1 {
    static void Main() {

        string[] datos = ["name:Andrea|age:29|state:Jalisco|zipcode:44100|status:Soltero",
                            "name:PedroL|age:22|state:Nayarit",
                            "name:Ana|age:19|state:Yucatán|zipcode:1234|status:Casado",
                            "name:Roberto|age:17|state:Sonora|status:Soltero",
                            "name:Elisa|age:30|state:DF|zipcode:99999|status:divorciado"]; // Un arreglo de strings con diferentes datos válidos y no válidos

        for (int i = 0; i < datos.Length; i++) { // For que recorre todo el arreglo para evitar repetir código.
            Console.WriteLine($"Validando datos #{i+1}...");
            Console.WriteLine(validarVersion(datos[i])); // Según el indice del arreglo, llama a la función "validarVersion" y manda el string con los datos.
        }

    }

    static string validarVersion(string datos) { // Función para validar los datos que recibe el string con los datos
        string resultadoStr; // String para guardar el resultado

        char delimitadorValor = ':'; // Delimitador para separar clave : valor
        char delimitadorCampo = '|'; // Delimitador para separar dato | dato

        bool esVersion4 = false; // Bandera para verificar la versión
        bool sonDatosValidos = true; // Bandera para verificar que son datos validos (Si un dato falla, la información ya no es válida)
        bool namePresente = false; // Bandera para verificar que "name" existe en los datos
        bool statePresente = false; // Bandera para verificar que "state" existe en los datos


        string[] partes = datos.Split(delimitadorCampo); // Separa los datos

        foreach (string campo in partes) { // Recorre los datos y obtiene los campos

            string[] valores = campo.Split(delimitadorValor); // Obtiene los valores en formato "clave : valor"
            if (valores.Length < 2) continue; // Si el dato no tiene el formato "clave : valor" continua al siguiente campo

            string clave = valores[0]; // Separa la clave en una variable independiente
            string valor = valores[1]; // Separa el valor en una variable independiente

            switch (clave) { // Verifica que clave estamos verificando
                case "name":
                    namePresente = true; // Si el nombre está presente, la bandera es verdadera
                    if(valor.Length < 5) sonDatosValidos = false; // Si el tamaño del nombre es menor a 5 los datos son invalidos
                    break;
                case "age":
                    if(int.TryParse(valor, out int edad)) { // Convierte la edad en un entero y devuelve verdadero si lo logra
                        if(edad < 18) sonDatosValidos = false; // Si la edad es menor a 18, los datos son invalidos
                    } else {
                        sonDatosValidos = false; // Si no puede transformar la edad en un entero, los datos son invalidos
                    }
                    break;
                case "state":
                    statePresente = true; // Si "state" está presente, la bandera es verdadera
                    if(valor.Length < 5) sonDatosValidos = false; // Si el tamaño es menor a 5, los datos son invalidos.
                    break;
                case "zipcode":
                    esVersion4 = true; // Si existe "zipcode" entonces es versión 4.0
                    if (valor.Length != 5) sonDatosValidos = false; // Si el tamaño no es justamente de 5, entonces los datos son invalidos
                    break;
                case "status":
                    esVersion4 = true; // Si existe "status" entonces es versión 4.0
                    string v = valor.ToLower(); // Convierte el valor a una cadena en minúsculas
                    if(v != "soltero" && v != "casado") sonDatosValidos = false; // verifica si el status es únicamente soltero o casado
                    break;
                default:
                    break;
            }
        }
        
        string resultado = (sonDatosValidos && namePresente && statePresente) ? "Validos" : "NO Validos"; // Verifica las banderas y determina la validez
        string version = esVersion4 ? "4.0" : "3.3"; // Verifica la versión con la bandera

        resultadoStr = $"Version: {version}|{resultado}"; // Agrega todo en un string con el formato solicitado

        return resultadoStr; // Retorna el resultado formateado
    }
}