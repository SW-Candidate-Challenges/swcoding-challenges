<?php
/*
¡Bienvenido al reto de programación!
Nombre del Reto: Sumasw
En este desafío, deberás implementar una función en el lenguaje de tu preferencia, que reciba dos números enteros, los sume y devuelva un mensaje indicando el resultado.

Descripción del Reto
Tu tarea es implementar una función sumarNumeros(a, b) que:

Verifique que ambos parámetros a y b sean números enteros.
Si alguno de los parámetros no es un número entero, la función debe retornar el mensaje: " Ambos parámetros deben ser números enteros.".
Si ambos parámetros son válidos, debe sumar los dos números y retornar un string con el siguiente formato: 
"El resultado de la suma es: Resultado SW", donde Resultado es la suma de a y b y "SW" son las iniciales.


✅ Casos válidos (números enteros)

Entrada	Salida esperada
a = 5, b = 3	El resultado de la suma es: 8 SW
a = -10, b = 4	El resultado de la suma es: -6 SW
a = 0, b = 0	El resultado de la suma es: 0 SW
a = 123, b = 877	El resultado de la suma es: 1000 SW

❌ Casos inválidos (no enteros)

Entrada	Salida esperada	Motivo del error
a = 5.5, b = 2	" Ambos parámetros deben ser números enteros."	a es un número decimal
a = "10", b = 5	" Ambos parámetros deben ser números enteros."	a es string
a = 8, b = nil (null)	" Ambos parámetros deben ser números enteros."	b no es un número
a = true, b = 3	" Ambos parámetros deben ser números enteros."	a es booleano
a = [], b = {}	" Ambos parámetros deben ser números enteros."	Ambos son tipos incorrectos
*/
$a = 0;
$b = 0;
    if(is_int($a) && is_int($b)){
     echo  $operacion = "El resultado de la suma es: ".$a + $b." SW";
    } else {
    if(is_float($a)){
     echo " Ambos parámetros deben ser números enteros "."(a)"." es un número decimal";
    }
    if(is_string($a)){
     echo " Ambos parámetros deben ser números enteros "."(a)"." es un número string";
    }
    if(is_null($a)){
     echo " Ambos parámetros deben ser números enteros "."(a)"." no es número";
    }
    if(is_bool($a)){
     echo " Ambos parámetros deben ser números enteros "."(a)"." es boolenno";
    }
    if(is_array($a)){
     echo " Ambos parámetros deben ser números enteros "."(a)"." es array";
    }
    if(is_float($b)){
     echo " Ambos parámetros deben ser números enteros "."(b)"." es un número decimal";
    }
    if(is_string($b)){
     echo " Ambos parámetros deben ser números enteros "."(b)"." es un número string";
    }
    if(is_null($b)){
     echo " Ambos parámetros deben ser números enteros "."(b)"." no es número";
    }
    if(is_bool($b)){
     echo " Ambos parámetros deben ser números enteros "."(b)"." es boolenno";
    }
    if(is_array($b)){
     echo " Ambos parámetros deben ser números enteros "."(b)"." es array";
    }
    
}
?>